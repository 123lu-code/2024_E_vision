# from maix import app, camera, display, image, time,uart
# import cv2
# import numpy as np

# # 串口发送间隔，单位：毫秒
# SEND_INTERVAL = 20  
# CAM_W = 320
# CAM_H = 240

# MIN_AREA = 1200
# # MIN_ASPECT = 0.45
# # MAX_ASPECT = 2.8
# # APPROX_EPSILON_RATIO = 0.02
# # ADAPTIVE_BLOCK_SIZE = 31
# # ADAPTIVE_C = 8
# MIN_ASPECT = 0.45
# MAX_ASPECT = 2.8
# APPROX_EPSILON_RATIO = 0.02
# ADAPTIVE_BLOCK_SIZE = 31
# ADAPTIVE_C = 8
# ser = uart.UART("/dev/serial0", 115200)

# def find_best_rectangle(img_cv):
#     gray = cv2.cvtColor(img_cv, cv2.COLOR_RGB2GRAY)
#     blur = cv2.GaussianBlur(gray, (5, 5), 0)
#     binary = cv2.adaptiveThreshold(
#         blur,
#         255,
#         cv2.ADAPTIVE_THRESH_MEAN_C,
#         cv2.THRESH_BINARY_INV,
#         ADAPTIVE_BLOCK_SIZE,
#         ADAPTIVE_C,
#     )

#     contours, _ = cv2.findContours(binary, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
#     best = None

#     for contour in contours:
#         area = cv2.contourArea(contour)
#         if area < MIN_AREA:
#             continue

#         perimeter = cv2.arcLength(contour, True)
#         approx = cv2.approxPolyDP(contour, APPROX_EPSILON_RATIO * perimeter, True)
#         if len(approx) != 4:
#             continue

#         x, y, w, h = cv2.boundingRect(approx)
#         if h == 0:
#             continue

#         aspect = w / h
#         if aspect < MIN_ASPECT or aspect > MAX_ASPECT:
#             continue

#         candidate = {
#             "area": area,
#             "rect": (x, y, w, h),
#             "approx": approx,
#         }

#         if best is None or area > best["area"]:
#             best = candidate

#     return best


# def order_points(points):
#     pts = points.reshape(4, 2).astype("float32")
#     ordered = np.zeros((4, 2), dtype="float32")

#     s = pts.sum(axis=1)
#     ordered[0] = pts[np.argmin(s)]
#     ordered[2] = pts[np.argmax(s)]

#     diff = np.diff(pts, axis=1).reshape(4)
#     ordered[1] = pts[np.argmin(diff)]
#     ordered[3] = pts[np.argmax(diff)]

#     return ordered


# def draw_ordered_points(img, ordered):
#     labels = ["TL", "TR", "BR", "BL"]
#     colors = [
#         image.COLOR_RED,
#         image.COLOR_GREEN,
#         image.COLOR_BLUE,
#         image.COLOR_YELLOW,
#     ]

#     for i, point in enumerate(ordered):
#         x, y = int(point[0]), int(point[1])
#         img.draw_circle(x, y, 5, colors[i], thickness=-1)
#         img.draw_string(x + 4, y + 4, labels[i], colors[i], scale=1)


# def draw_polygon(img, ordered):
#     pts = ordered.astype("int32")
#     for i in range(4):
#         x1, y1 = int(pts[i][0]), int(pts[i][1])
#         x2, y2 = int(pts[(i + 1) % 4][0]), int(pts[(i + 1) % 4][1])
#         img.draw_line(x1, y1, x2, y2, image.COLOR_GREEN, thickness=2)


# def get_polygon_center(ordered):
#     tl, tr, br, bl = ordered
#     x1, y1 = tl
#     x2, y2 = br
#     x3, y3 = tr
#     x4, y4 = bl

#     denominator = (x1 - x2) * (y3 - y4) - (y1 - y2) * (x3 - x4)
#     if abs(denominator) < 1e-6:
#         center = ordered.mean(axis=0)
#         return int(center[0]), int(center[1])

#     px = ((x1 * y2 - y1 * x2) * (x3 - x4) - (x1 - x2) * (x3 * y4 - y3 * x4)) / denominator
#     py = ((x1 * y2 - y1 * x2) * (y3 - y4) - (y1 - y2) * (x3 * y4 - y3 * x4)) / denominator
#     return int(px), int(py)


# def warp_perspective_target(img_cv, ordered):
#     tl, tr, br, bl = ordered

#     width_top = np.linalg.norm(tr - tl)
#     width_bottom = np.linalg.norm(br - bl)
#     height_left = np.linalg.norm(bl - tl)
#     height_right = np.linalg.norm(br - tr)

#     warp_w = int(max(width_top, width_bottom))
#     warp_h = int(max(height_left, height_right))

#     if warp_w < 20 or warp_h < 20:
#         return None

#     dst = np.array(
#         [
#             [0, 0],
#             [warp_w - 1, 0],
#             [warp_w - 1, warp_h - 1],
#             [0, warp_h - 1],
#         ],
#         dtype="float32",
#     )

#     matrix = cv2.getPerspectiveTransform(ordered, dst)
#     if abs(np.linalg.det(matrix)) < 1e-6:
#         return None
#     warped = cv2.warpPerspective(img_cv, matrix, (warp_w, warp_h))

#     return {
#         "image": warped,
#         "matrix": matrix,
#         "size": (warp_w, warp_h),
#     }



# cam = camera.Camera(CAM_W, CAM_H)
# disp = display.Display()
# last_send_time = time.ticks_ms()  # 新增：记录上一次发送的时间
# while not app.need_exit():
#     img = cam.read()
#     img_cv = image.image2cv(img, False, False)

#     best = find_best_rectangle(img_cv)
#     if not best:
#         img.draw_string(8, 8, "no rectangle", image.COLOR_RED, scale=1)
#         fps = time.fps()
#         if fps > 0:
#             img.draw_string(8, 28, f"fps: {fps:.1f}", image.COLOR_WHITE, scale=1)
#         now = time.ticks_ms()
#         if now - last_send_time >= SEND_INTERVAL:
#             print("0,0*")
#             ser.write("0,0*".encode())
#             last_send_time = now
#         disp.show(img)
#         continue

#     ordered = order_points(best["approx"])
#     warp_result = warp_perspective_target(img_cv, ordered)
#     if not warp_result:
#         img.draw_string(8, 8, "warp failed", image.COLOR_RED, scale=1)
#         fps = time.fps()
#         if fps > 0:
#             img.draw_string(8, 28, f"fps: {fps:.1f}", image.COLOR_WHITE, scale=1)
#         now = time.ticks_ms()
#         if now - last_send_time >= SEND_INTERVAL:
#             print("0,0*")
#             ser.write("0,0*".encode())
#             last_send_time = now
#         disp.show(img)
#         continue

#     std_h, std_w = warp_result["image"].shape[:2]
#     center_std = (std_w // 2, std_h // 2)

#     std_center_points = np.array([[center_std]], dtype=np.float32)
#     M_inv = np.linalg.inv(warp_result["matrix"])
#     original_center_point = cv2.perspectiveTransform(std_center_points, M_inv)[0][0]
#     ox, oy = int(original_center_point[0]), int(original_center_point[1])

#     screen_center = (img.width() // 2, img.height() // 2)
#     err_x = ox - screen_center[0]-8
#     err_y = oy - screen_center[1]-10

#     draw_polygon(img, ordered)
#     img.draw_circle(ox, oy, 4, image.COLOR_RED, thickness=-1)
#     img.draw_circle(screen_center[0], screen_center[1], 4, image.COLOR_BLUE, thickness=-1)
#     img.draw_string(8, 8, f"err=({err_x},{err_y})", image.COLOR_GREEN, scale=1)

#     fps = time.fps()
#     if fps > 0:
#         img.draw_string(8, 28, f"fps: {fps:.1f}", image.COLOR_WHITE, scale=1)
    
#     # 计算时间差，达到间隔才发送
#     now = time.ticks_ms()
#     if now - last_send_time >= SEND_INTERVAL:
#         print(f"{err_x},{err_y}*")
#         send_data = "{},{}*".format(err_x, err_y)
#         ser.write(send_data.encode())
#         last_send_time = now  # 更新上次发送时间
#     disp.show(img)


# 导入MaixPy官方硬件驱动库，包含应用管理、摄像头、显示、图像处理、时间、串口等模块
from maix import app, camera, display, image, time, uart
# 导入OpenCV计算机视觉库，用于图像处理、轮廓检测、透视变换等核心算法
import cv2
# 导入numpy数值计算库，用于矩阵运算、坐标点处理
import numpy as np

# ========== 全局参数配置 ==========
# 串口发送间隔，单位：毫秒，控制向下位机发送数据的频率
SEND_INTERVAL = 20
# 摄像头采集分辨率宽度
CAM_W = 320
# 摄像头采集分辨率高度
CAM_H = 240

# 最小轮廓面积阈值（单位：像素²），小于该值的轮廓直接过滤，用于排除细小噪点
MIN_AREA = 1200
# 矩形最小长宽比，宽高比小于该值的轮廓判定为无效矩形
MIN_ASPECT = 0.45
# 矩形最大长宽比，宽高比大于该值的轮廓判定为无效矩形
MAX_ASPECT = 2.8
# 多边形逼近精度系数，值越小拟合越严格，值越大拟合越宽松
APPROX_EPSILON_RATIO = 0.02
# 自适应二值化邻域窗口大小，必须为奇数，值越大局部阈值计算范围越广
ADAPTIVE_BLOCK_SIZE = 31
# 自适应二值化阈值偏移量，值越小越容易将像素判定为前景目标
ADAPTIVE_C = 8

# 初始化串口外设，设备节点为/dev/serial0，波特率115200，用于和下位机通信
ser = uart.UART("/dev/serial0", 115200)


# ========== 矩形检测函数 ==========
# 功能：输入OpenCV格式图像，输出画面中面积最大、符合筛选条件的矩形信息
def find_best_rectangle(img_cv):
    # 将彩色RGB图像转换为灰度图，减少计算量，后续处理均基于灰度图
    gray = cv2.cvtColor(img_cv, cv2.COLOR_RGB2GRAY)
    # 对灰度图进行5×5高斯模糊，平滑图像、消除噪点，减少后续二值化的干扰
    blur = cv2.GaussianBlur(gray, (5, 5), 0)
    # 自适应阈值二值化处理，适配光照不均匀环境，输出黑白二值图像
    binary = cv2.adaptiveThreshold(
        blur,               # 输入模糊后的灰度图
        255,                # 满足阈值的像素赋值为255（白色）
        cv2.ADAPTIVE_THRESH_MEAN_C,  # 采用局部均值法计算阈值
        cv2.THRESH_BINARY_INV,       # 反二值化，亮背景下的深色目标变为白色
        ADAPTIVE_BLOCK_SIZE,         # 邻域窗口大小
        ADAPTIVE_C                   # 阈值偏移补偿量
    )

    # 提取二值图中所有外轮廓，只保留最外层轮廓，压缩轮廓拐点以减少计算量
    contours, _ = cv2.findContours(binary, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    # 初始化最优矩形变量，用于存储筛选后的结果
    best = None

    # 遍历所有检测到的轮廓，逐个筛选
    for contour in contours:
        # 计算当前轮廓的像素面积
        area = cv2.contourArea(contour)
        # 面积小于最小阈值，直接跳过，过滤小噪点
        if area < MIN_AREA:
            continue

        # 计算轮廓的周长（闭合轮廓）
        perimeter = cv2.arcLength(contour, True)
        # 用多边形逼近轮廓，简化轮廓形状，精度与周长成正比
        approx = cv2.approxPolyDP(contour, APPROX_EPSILON_RATIO * perimeter, True)
        # 逼近后的顶点数不等于4，说明不是四边形，直接跳过
        if len(approx) != 4:
            continue

        # 获取逼近后四边形的外接矩形左上角坐标(x,y)、宽度w、高度h
        x, y, w, h = cv2.boundingRect(approx)
        # 高度为0判定为无效轮廓，跳过
        if h == 0:
            continue

        # 计算矩形的宽高比
        aspect = w / h
        # 宽高比不在预设范围内，判定为无效矩形，跳过
        if aspect < MIN_ASPECT or aspect > MAX_ASPECT:
            continue

        # 符合所有条件的矩形封装为候选对象
        candidate = {
            "area": area,       # 轮廓面积
            "rect": (x, y, w, h),  # 外接矩形参数
            "approx": approx    # 四边形四个角点坐标
        }

        # 始终保留面积最大的矩形作为最优结果，避免画面中多个矩形产生干扰
        if best is None or area > best["area"]:
            best = candidate

    # 返回最优矩形信息，未找到则返回None
    return best


# ========== 角点排序函数 ==========
# 功能：将矩形4个角点按「左上、右上、右下、左下」固定顺序排列，为透视变换做准备
def order_points(points):
    # 将输入的轮廓点重塑为4行2列的坐标数组，转换为float32类型
    pts = points.reshape(4, 2).astype("float32")
    # 初始化空数组，用于存放排序后的角点
    ordered = np.zeros((4, 2), dtype="float32")

    # 计算每个点的x+y坐标和
    s = pts.sum(axis=1)
    # 坐标和最小的点为左上角
    ordered[0] = pts[np.argmin(s)]
    # 坐标和最大的点为右下角
    ordered[2] = pts[np.argmax(s)]

    # 计算每个点的y-x坐标差
    diff = np.diff(pts, axis=1).reshape(4)
    # 坐标差最小的点为右上角
    ordered[1] = pts[np.argmin(diff)]
    # 坐标差最大的点为左下角
    ordered[3] = pts[np.argmax(diff)]

    # 返回排序后的角点数组
    return ordered


# # ========== 角点绘制函数 ==========
# # 功能：在画面上绘制四个角点的彩色标记与标签，用于调试角点排序是否正确
# def draw_ordered_points(img, ordered):
#     # 四个角点的位置标签
#     labels = ["TL", "TR", "BR", "BL"]
#     # 四个角点对应的颜色：红、绿、蓝、黄
#     colors = [
#         image.COLOR_RED,
#         image.COLOR_GREEN,
#         image.COLOR_BLUE,
#         image.COLOR_YELLOW,
#     ]

#     # 遍历四个角点，逐个绘制圆点和标签
#     for i, point in enumerate(ordered):
#         # 获取角点的x、y坐标，转换为整数
#         x, y = int(point[0]), int(point[1])
#         # 在角点位置绘制实心圆，半径为5像素
#         img.draw_circle(x, y, 5, colors[i], thickness=-1)
#         # 在圆点右下角绘制位置标签文字
#         img.draw_string(x + 4, y + 4, labels[i], colors[i], scale=1)


# ========== 矩形框绘制函数 ==========
# 功能：在画面上绘制识别到的矩形边框，直观标记目标位置
def draw_polygon(img, ordered):
    # 将角点坐标转换为整数类型
    pts = ordered.astype("int32")
    # 循环连接四个顶点，最后一个点连回第一个点，形成闭合矩形
    for i in range(4):
        # 当前点坐标
        x1, y1 = int(pts[i][0]), int(pts[i][1])
        # 下一个点坐标，取模实现首尾相连
        x2, y2 = int(pts[(i + 1) % 4][0]), int(pts[(i + 1) % 4][1])
        # 绘制绿色线段，线宽2像素
        img.draw_line(x1, y1, x2, y2, image.COLOR_GREEN, thickness=2)


# # ========== 四边形中心计算函数 ==========
# # 功能：通过对角线交点公式，精准计算不规则四边形的几何中心
# def get_polygon_center(ordered):
#     # 拆分四个角点：左上、右上、右下、左下
#     tl, tr, br, bl = ordered
#     # 左上-右下对角线的两个端点
#     x1, y1 = tl
#     x2, y2 = br
#     # 右上-左下对角线的两个端点
#     x3, y3 = tr
#     x4, y4 = bl

#     # 计算直线交点公式的分母
#     denominator = (x1 - x2) * (y3 - y4) - (y1 - y2) * (x3 - x4)
#     # 分母接近0，说明两条线近乎平行，降级为取四个点的平均值作为中心
#     if abs(denominator) < 1e-6:
#         center = ordered.mean(axis=0)
#         return int(center[0]), int(center[1])

#     # 代入直线交点公式，计算对角线交点的x坐标
#     px = ((x1 * y2 - y1 * x2) * (x3 - x4) - (x1 - x2) * (x3 * y4 - y3 * x4)) / denominator
#     # 代入直线交点公式，计算对角线交点的y坐标
#     py = ((x1 * y2 - y1 * x2) * (y3 - y4) - (y1 - y2) * (x3 * y4 - y3 * x4)) / denominator
#     # 返回四边形中心的整数坐标
#     return int(px), int(py)


# ========== 透视变换函数 ==========
# 功能：将倾斜的矩形透视校正为正视图，消除透视畸变，提升中心定位精度
def warp_perspective_target(img_cv, ordered):
    # 拆分四个角点
    tl, tr, br, bl = ordered

    # 计算上边的像素长度
    width_top = np.linalg.norm(tr - tl)
    # 计算下边的像素长度
    width_bottom = np.linalg.norm(br - bl)
    # 计算左边的像素长度
    height_left = np.linalg.norm(bl - tl)
    # 计算右边的像素长度
    height_right = np.linalg.norm(br - tr)

    # 取上下边的最大值作为变换后图像的宽度
    warp_w = int(max(width_top, width_bottom))
    # 取左右边的最大值作为变换后图像的高度
    warp_h = int(max(height_left, height_right))

    # 变换后尺寸过小，判定为无效目标，直接返回
    if warp_w < 20 or warp_h < 20:
        return None

    # 定义变换后的目标坐标，四个角对应新图像的四个顶点
    dst = np.array(
        [
            [0, 0],                  # 左上
            [warp_w - 1, 0],         # 右上
            [warp_w - 1, warp_h - 1],# 右下
            [0, warp_h - 1],         # 左下
        ],
        dtype="float32",
    )

    # 根据原始角点和目标角点，计算3×3透视变换矩阵
    matrix = cv2.getPerspectiveTransform(ordered, dst)
    # 计算矩阵行列式，接近0则为奇异矩阵（不可逆），直接返回None防止后续崩溃
    if abs(np.linalg.det(matrix)) < 1e-6:
        return None
    # 执行透视变换，输出扶正后的矩形图像
    warped = cv2.warpPerspective(img_cv, matrix, (warp_w, warp_h))

    # 返回变换后的图像、变换矩阵、变换后尺寸
    return {
        "image": warped,
        "matrix": matrix,
        "size": (warp_w, warp_h),
    }


# ========== 程序初始化 ==========
# 初始化摄像头，设置采集分辨率
cam = camera.Camera(CAM_W, CAM_H)
# 初始化显示屏
disp = display.Display()
# 记录程序启动时的时间戳，用于计算串口发送间隔
last_send_time = time.ticks_ms()


# ========== 主循环（程序核心执行流程） ==========
while not app.need_exit():
    # 采集一帧摄像头图像，为MaixPy原生图像格式
    img = cam.read()
    # 将MaixPy图像转换为OpenCV可处理的numpy格式，不转BGR、不复制数据
    img_cv = image.image2cv(img, False, False)

    # 调用矩形检测函数，在当前画面中寻找符合条件的最大矩形
    best = find_best_rectangle(img_cv)

    # ---------- 分支1：未检测到有效矩形 ----------
    if not best:
        # 在画面左上角绘制红色提示文字：未检测到矩形
        img.draw_string(8, 8, "no rectangle", image.COLOR_RED, scale=1)
        # 计算实时运行帧率
        fps = time.fps()
        # 帧率有效时，在画面第二行显示帧率数值
        if fps > 0:
            img.draw_string(8, 28, f"fps: {fps:.1f}", image.COLOR_WHITE, scale=1)

        # 获取当前时间戳
        now = time.ticks_ms()
        # # 达到设定的发送间隔时，向下位机发送目标丢失信号
        # if now - last_send_time >= SEND_INTERVAL:
        # 计算本次实际发送间隔
        interval = now - last_send_time
        # 控制台打印：间隔 + 发送内容
        print(f"[{interval}ms] 发送: 0,0*")
        # 串口发送0,0*，表示未识别到目标
        ser.write("0,0*".encode())
        # 更新上一次发送的时间戳
        last_send_time = now

        # 刷新屏幕显示当前画面
        disp.show(img)
        # 跳过后续逻辑，直接进入下一帧循环
        continue

    # 检测到矩形后，先对角点进行固定顺序排序
    ordered = order_points(best["approx"])
    # 执行透视变换，将矩形扶正
    warp_result = warp_perspective_target(img_cv, ordered)

    # ---------- 分支2：检测到矩形，但透视变换失败 ----------
    if not warp_result:
        # 在画面左上角绘制红色提示文字：透视变换失败
        img.draw_string(8, 8, "warp failed", image.COLOR_RED, scale=1)
        # 计算并显示帧率
        fps = time.fps()
        if fps > 0:
            img.draw_string(8, 28, f"fps: {fps:.1f}", image.COLOR_WHITE, scale=1)

        # 达到发送间隔时，同样发送目标丢失信号
        now = time.ticks_ms()
        # if now - last_send_time >= SEND_INTERVAL:
        # 计算本次实际发送间隔
        interval = now - last_send_time
        # 控制台打印：间隔 + 发送内容
        print(f"[{interval}ms] 发送: 0,0*")
        ser.write("0,0*".encode())
        last_send_time = now

        # 刷新屏幕，进入下一帧
        disp.show(img)
        continue

    # ---------- 分支3：检测成功，计算偏差并发送 ----------
    # 获取透视变换后图像的高度和宽度
    std_h, std_w = warp_result["image"].shape[:2]
    # 计算扶正后图像的中心坐标
    center_std = (std_w // 2, std_h // 2)

    # 将中心坐标封装为透视变换所需的三维数组格式
    std_center_points = np.array([[center_std]], dtype=np.float32)
    # 计算透视矩阵的逆矩阵，用于将扶正图的坐标映射回原图
    M_inv = np.linalg.inv(warp_result["matrix"])
    # 执行逆透视变换，得到矩形中心在原始画面中的真实坐标
    original_center_point = cv2.perspectiveTransform(std_center_points, M_inv)[0][0]
    # 转换为整数像素坐标
    ox, oy = int(original_center_point[0]), int(original_center_point[1])

    # 计算屏幕画面的中心坐标
    screen_center = (img.width() // 2, img.height() // 2)
    # 计算水平方向偏差：靶心x - 屏幕中心x - 校准偏移量
    err_x = ox - screen_center[0] 
    # 计算垂直方向偏差：靶心y - 屏幕中心y - 校准偏移量
    err_y = oy - screen_center[1] - 3

    # 在画面上绘制绿色矩形框，标记识别到的目标
    draw_polygon(img, ordered)
    # 绘制红色实心点，标记矩形靶心中心
    img.draw_circle(ox, oy, 4, image.COLOR_RED, thickness=-1)
    # 绘制蓝色实心点，标记屏幕中心
    img.draw_circle(screen_center[0], screen_center[1], 4, image.COLOR_BLUE, thickness=-1)
    # 在画面左上角显示实时偏差值
    img.draw_string(8, 8, f"err=({err_x},{err_y})", image.COLOR_GREEN, scale=1)

    # 计算并显示当前运行帧率
    fps = time.fps()
    if fps > 0:
        img.draw_string(8, 28, f"fps: {fps:.1f}", image.COLOR_WHITE, scale=1)

    # 获取当前时间戳
    now = time.ticks_ms()
    # # 达到发送间隔时，向下位机发送真实偏差数据
    # if now - last_send_time >= SEND_INTERVAL:
    interval = now - last_send_time
    # 控制台打印：间隔 + 实际偏差值
    print(f"[{interval}ms] 发送: {err_x},{err_y}*")
    # 拼接为x,y*格式的字符串
    send_data = "{},{}*".format(err_x, err_y)
    # 转换为字节流，通过串口发送
    ser.write(send_data.encode())
    # 更新上一次发送时间戳
    last_send_time = now

    # 刷新屏幕，显示当前帧的所有画面与标记
    disp.show(img)
